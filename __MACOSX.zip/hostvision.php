<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="robots" content="noindex" />
<title><?php echo $_SERVER['HTTP_HOST']; ?> | HostVision Romania</title>
<link href="http://www.hostvision.ro/css/welcome.css" rel="stylesheet" type="text/css" />
<link href="http://www.hostvision.ro/idisk.ico" rel="shortcut icon" type="image/x-icon" />
</head>
<body>
<div id="container"><div id="welcome">Bine ai venit!<div class="sub">Welcome / Bienvenida / Willkommen / Bienvenue / Benvenuti</div></div> <h2><?php echo str_replace('www.', '', $_SERVER['HTTP_HOST']); ?></h2><div id="smlinks"><a href="http://www.hostvision.ro/inregistrare_domenii.php" title="Inregistrare Domenii" target="_blank" rel="nofollow">inregistrare domenii</a> | <a href="http://www.hostvision.ro/gazduire_web.php" title="Gazduire Web" target="_blank" rel="nofollow">gazduire web</a> | <a href="http://www.hostvision.ro/reseller-business-romania.php" title="Reseller Hosting" target="_blank" rel="nofollow">reseller hosting</a> | <a href="http://support.hostvision.ro/" title="Suport Clienti hostvision" target="_blank" rel="nofollow">suport clienti</a></div></div>
</body>
</html>